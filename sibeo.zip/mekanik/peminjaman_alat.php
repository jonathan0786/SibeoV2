<?php
session_start();
include "../config/koneksi.php";

// 1. KEAMANAN AKSES
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'mekanik') {
    header("Location: ../auth/login.php");
    exit();
}

$id_mekanik = $_SESSION['id'];

// 2. PROSES INPUT PEMINJAMAN ALAT BARU
if (isset($_POST['pinjam_alat'])) {
    $id_pengerjaan = mysqli_real_escape_string($koneksi, $_POST['id_pengerjaan']);
    $id_alat = mysqli_real_escape_string($koneksi, $_POST['id_alat']);
    $jumlah_pinjam = mysqli_real_escape_string($koneksi, $_POST['jumlah_pinjam']);
    $waktu_pinjam = date('Y-m-d H:i:s'); 
    $status = "dipinjam"; 

    $query_insert = "INSERT INTO tbl_peminjaman_alat (id_pengerjaan, id_alat, jumlah_pinjam, waktu_pinjam, status) 
                     VALUES ('$id_pengerjaan', '$id_alat', '$jumlah_pinjam', '$waktu_pinjam', '$status')";
    
    if (mysqli_query($koneksi, $query_insert)) {
        echo "<script>alert('Peminjaman alat berhasil dicatat!'); window.location='peminjaman_alat.php';</script>";
    } else {
        echo "<script>alert('Gagal melakukan peminjaman: " . mysqli_error($koneksi) . "');</script>";
    }
}

// 3. PROSES PENGEMBALIAN ALAT
if (isset($_GET['aksi']) && $_GET['aksi'] == 'kembali') {
    $id_peminjaman = mysqli_real_escape_string($koneksi, $_GET['id']);
    $waktu_kembali = date('Y-m-d H:i:s');

    // Update status menjadi dikembalikan murni berdasarkan ID Peminjaman
    $query_kembali = "UPDATE tbl_peminjaman_alat SET 
                        waktu_kembali = '$waktu_kembali', 
                        status = 'dikembalikan' 
                      WHERE id_peminjaman = '$id_peminjaman'";

    if (mysqli_query($koneksi, $query_kembali)) {
        echo "<script>alert('Alat berhasil dikembalikan!'); window.location='peminjaman_alat.php';</script>";
    } else {
        echo "<script>alert('Gagal memproses pengembalian!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Alat - SIBEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
        
        .btn-primary {
    background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
    border: none;
    font-weight: 600;
    transition: all 0.2s ease;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2);
}

/* Menyamakan style modal agar melengkung halus (modern) */
.modal-content {
    border: none;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.1);
}

.modal-header {
    border-bottom: 1px solid #f1f5f9;
    padding: 20px 24px;
}

.modal-footer {
    border-top: 1px solid #f1f5f9;
    padding: 16px 24px;
}

/* Menyamakan elemen input & select di dalam modal */
.form-control, .form-select {
    border-radius: 10px;
    border: 1px solid #cbd5e1;
    padding: 10px 14px;
    font-size: 14px;
    color: #1e293b;
    transition: all 0.2s ease;
}

.form-control:focus, .form-select:focus {
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
}
font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f1f5f9; color: #1e293b; }
.sidebar { background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%); z-index: 1045; border-right: 1px solid rgba(255, 255, 255, 0.08); }
@media (min-width: 768px) {
    .sidebar { height: 100vh; position: fixed; top: 0; left: 0; bottom: 0; width: 25%; box-shadow: 4px 0 30px rgba(15, 23, 42, 0.2); display: flex; flex-direction: column; justify-content: space-between; }
    }
@media (min-width: 992px) { .sidebar { width: 16.666667%; } }
    .sidebar-brand-wrapper { padding: 30px 24px 20px 24px; }
    .sidebar-brand { font-size: 24px; font-weight: 800; letter-spacing: 1.5px; background: linear-gradient(45deg, #38bdf8, #3b82f6); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .sidebar .nav-link { color: #94a3b8; font-size: 14px; font-weight: 500; padding: 14px 24px; display: flex; align-items: center; transition: all 0.2s ease; border-left: 4px solid transparent; }
    .sidebar .nav-link i { font-size: 16px; width: 28px; color: #64748b; }
    .sidebar .nav-link:hover { color: #38bdf8; background: rgba(255, 255, 255, 0.04); }
    .sidebar .nav-link.active { background: rgba(56, 189, 248, 0.1); color: #38bdf8; font-weight: 600; border-left-color: #38bdf8; }
    .main-wrapper { padding: 20px; margin-left: 0; transition: all 0.3s ease; }
    @media (min-width: 768px) { .main-wrapper { margin-left: 25%; padding: 40px; } }
    @media (min-width: 992px) { .main-wrapper { margin-left: 16.666667%; } }
    .table-premium { background: white; border-radius: 24px; box-shadow: 0 4px 18px rgba(148, 163, 184, 0.08); padding: 25px; }
    .table-premium thead th { background-color: #f8fafc; color: #64748b; font-size: 12px; font-weight: 700; text-transform: uppercase; padding: 16px 20px; border-bottom: none; }
    .table-premium tbody td { padding: 18px 20px; border-bottom: 1px solid #f1f5f9; color: #475569; font-size: 14px; }
    </style>
</head>
<body>

<div class="bg-dark text-white d-md-none p-3 sticky-top d-flex justify-content-between align-items-center shadow-sm">
    <div class="fw-bold fs-5" style="background: linear-gradient(45deg, #38bdf8, #3b82f6); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">SIBEO</div>
    <button class="btn btn-outline-light btn-sm px-2.5" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu"><i class="fa-solid fa-bars"></i> Menu</button>
</div>

<div class="container-fluid p-0">
    <div class="offcanvas-md offcanvas-start sidebar" tabindex="-1" id="sidebarMenu">
        <div class="d-flex flex-column justify-content-between h-100 w-100">
            <div>
                <div class="sidebar-brand-wrapper d-flex justify-content-between align-items-center">
                    <div class="sidebar-brand">SIBEO</div>
                    <button type="button" class="btn-close btn-close-white d-md-none" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu"></button>
                </div>
                <div class="nav flex-column">
                    <a href="dashboard.php" class="nav-link"><i class="fa-solid fa-chart-simple me-3"></i>Dashboard Kerja</a>
                    <a href="pengerjaan.php" class="nav-link"><i class="fa-solid fa-screwdriver-wrench me-3"></i>Pengerjaan</a>
                    <a href="peminjaman_alat.php" class="nav-link active"><i class="fa-solid fa-boxes-stacked me-3"></i>Peminjaman Alat</a>
                </div>
            </div>
            <div class="mb-4 pt-2 border-top border-secondary">
                <div class="nav flex-column">
                    <a href="../auth/logout.php" class="nav-link text-danger" onclick="return confirm('Keluar dari sistem')"><i class="fa-solid fa-sign-out-alt me-3 text-danger"></i>Keluar</a>
                </div>
            </div>
        </div>
    </div>

    <div class="main-wrapper">
        <div class="mb-4 d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <h3 class="fw-bold m-0 text-dark">Peminjaman Alat Kerja</h3>
                <p class="text-muted small m-0 mt-1">Daftar perkakas bengkel yang digunakan dalam pengerjaan servis.</p>
            </div>
            <button class="btn btn-primary px-6 py-2.5 d-flex align-items-center gap-2 shadow-sm text-uppercase" style="border-radius: 12px; font-size: 13px; letter-spacing: 0.5px;" data-bs-toggle="modal" data-bs-target="#modalPinjam">
            <i class="fa-solid fa-plus fs-6"></i> Pinjam Alat Baru
            </button>
        </div>

        <div class="table-premium">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>ID PINJAM</th>
                            <th>KODE BOOKING</th>
                            <th>NAMA ALAT</th>
                            <th class="text-center">QTY</th>
                            <th>WAKTU PINJAM</th>
                            <th>WAKTU KEMBALI</th>
                            <th>STATUS</th>
                            <th class="text-center">AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    // Query JOIN 3 Tabel menyesuaikan skema database milik Anda
                    $query_pinjam = mysqli_query($koneksi, "SELECT p.*, a.nama_alat, pg.id_booking, b.kode_booking 
                                                            FROM tbl_peminjaman_alat p
                                                            JOIN tbl_alat_kerja a ON p.id_alat = a.id_alat
                                                            JOIN tbl_pengerjaan pg ON p.id_pengerjaan = pg.id_pengerjaan
                                                            JOIN tbl_booking b ON pg.id_booking = b.id_booking
                                                            WHERE pg.id_mekanik = '$id_mekanik'
                                                            ORDER BY p.id_peminjaman DESC");

                    if (!$query_pinjam || mysqli_num_rows($query_pinjam) == 0) {
                        echo "<tr><td colspan='8' class='text-center text-muted py-4 small'>Belum ada riwayat peminjaman alat kerja.</td></tr>";
                    } else {
                        while ($r = mysqli_fetch_assoc($query_pinjam)) {
                            $status = $r['status'];
                            $badge = ($status == "dipinjam") ? "bg-warning text-warning" : "bg-success text-success";
                            ?>
                            <tr>
                                <td class="text-secondary fw-bold">#PA-<?= $r['id_peminjaman']; ?></td>
                                <td class="fw-bold text-primary"><?= htmlspecialchars($r['kode_booking']); ?></td>
                                <td class="fw-semibold text-dark"><?= htmlspecialchars($r['nama_alat']); ?></td>
                                <td class="text-center fw-bold text-dark"><?= $r['jumlah_pinjam']; ?></td>
                                <td style="font-size: 13px;"><?= $r['waktu_pinjam']; ?></td>
                                <td style="font-size: 13px;"><?= (!empty($r['waktu_kembali']) && $r['waktu_kembali'] != '0000-00-00 00:00:00') ? $r['waktu_kembali'] : '<span class="text-muted">-</span>'; ?></td>
                                <td>
                                    <span class="badge bg-opacity-10 <?= $badge; ?> px-2.5 py-1.5 rounded text-capitalize" style="font-size: 12px; font-weight: 600;"><?= $status; ?></span>
                                </td>
                                <td class="text-center">
                                    <?php if ($status == 'dipinjam'): ?>
                                        <a href="peminjaman_alat.php?aksi=kembali&id=<?= $r['id_peminjaman']; ?>" class="btn btn-sm btn-outline-success px-3 rounded-pill" onclick="return confirm('Apakah Anda ingin mengembalikan alat ini?')">
                                            <i class="fa-solid fa-arrow-rotate-left me-1"></i> Kembalikan
                                        </a>
                                    <?php else: ?>
                                        <button class="btn btn-sm btn-light px-3 rounded-pill text-muted" disabled><i class="fa-solid fa-circle-check"></i> Kembali</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalPinjam" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 16px;">
            <form method="POST" action="">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Formulir Pinjam Alat Kerja</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-muted">UNTUK TUGAS PENGERJAAN (KODE BOOKING)</label>
                        <select class="form-select" name="id_pengerjaan" required>
                            <option value="">-- Pilih Tugas / Kode Booking --</option>
                            <?php
                            $tugas_aktif = mysqli_query($koneksi, "SELECT p.id_pengerjaan, b.kode_booking, k.merk FROM tbl_pengerjaan p 
                                                                   JOIN tbl_booking b ON p.id_booking = b.id_booking 
                                                                   JOIN tbl_kendaraan k ON b.id_kendaraan = k.id_kendaraan
                                                                   WHERE p.id_mekanik = '$id_mekanik' AND p.status != 'Selesai'");
                            while($t = mysqli_fetch_assoc($tugas_aktif)){
                                echo "<option value='".$t['id_pengerjaan']."'>".$t['kode_booking']." - ".htmlspecialchars($t['merk'])."</option>";
                            }
                            if(mysqli_num_rows($tugas_aktif) == 0){
                                echo "<option value='' disabled>Anda tidak memiliki tugas aktif berjalan</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-muted">PILIH ALAT BENGKEL</label>
                        <select class="form-select" name="id_alat" required>
                            <option value="">-- Pilih Perkakas/Tools --</option>
                            <?php
                            $alat_master = mysqli_query($koneksi, "SELECT id_alat, nama_alat, kondisi FROM tbl_alat_kerja WHERE kondisi = 'baik' ORDER BY nama_alat ASC");
                            while($a = mysqli_fetch_assoc($alat_master)){
                                echo "<option value='".$a['id_alat']."'>".htmlspecialchars($a['nama_alat'])."</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="mb-2">
                        <label class="form-label fw-semibold small text-muted">JUMLAH PINJAM (QTY)</label>
                        <input type="number" class="form-control" name="jumlah_pinjam" min="1" value="1" required>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="pinjam_alat" class="btn btn-sm btn-primary px-3">Simpan Peminjaman</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>