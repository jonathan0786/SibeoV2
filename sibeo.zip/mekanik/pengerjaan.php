<?php
session_start();
include "../config/koneksi.php";

// 1. KEAMANAN AKSES
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'mekanik') {
    header("Location: ../auth/login.php");
    exit();
}

$id_mekanik = $_SESSION['id'];

// 2. PROSES UPDATE STATUS & CATATAN MEKANIK
if (isset($_POST['update_pengerjaan'])) {
    $id_pengerjaan = mysqli_real_escape_string($koneksi, $_POST['id_pengerjaan']);
    $status_baru = mysqli_real_escape_string($koneksi, $_POST['status_pengerjaan']);
    $catatan = mysqli_real_escape_string($koneksi, $_POST['catatan_mekanik']);
    
    // Jika status diubah menjadi Selesai, set waktu_selesai ke jam sekarang
    if ($status_baru == 'Selesai') {
        $waktu_sekarang = date('Y-m-d H:i:s');
        $query_update = "UPDATE tbl_pengerjaan SET 
                            status_pengerjaan = '$status_baru', 
                            catatan_mekanik = '$catatan', 
                            waktu_selesai = '$waktu_sekarang' 
                         WHERE id_pengerjaan = '$id_pengerjaan' AND id_mekanik = '$id_mekanik'";
    } else {
        // Jika status diubah ke Proses/Sedang Dikerjakan dan waktu_mulai masih kosong, isi waktu_mulai
        $query_cek = mysqli_query($koneksi, "SELECT waktu_mulai FROM tbl_pengerjaan WHERE id_pengerjaan = '$id_pengerjaan'");
        $data_cek = mysqli_fetch_assoc($query_cek);
        
        if (empty($data_cek['waktu_mulai']) || $data_cek['waktu_mulai'] == '0000-00-00 00:00:00') {
            $waktu_mulai = date('Y-m-d H:i:s');
            $query_update = "UPDATE tbl_pengerjaan SET 
                                status_pengerjaan = '$status_baru', 
                                catatan_mekanik = '$catatan', 
                                waktu_mulai = '$waktu_mulai' 
                             WHERE id_pengerjaan = '$id_pengerjaan' AND id_mekanik = '$id_mekanik'";
        } else {
            $query_update = "UPDATE tbl_pengerjaan SET 
                                status_pengerjaan = '$status_baru', 
                                catatan_mekanik = '$catatan' 
                             WHERE id_pengerjaan = '$id_pengerjaan' AND id_mekanik = '$id_mekanik'";
        }
    }
    
    if (mysqli_query($koneksi, $query_update)) {
        echo "<script>alert('Status pengerjaan berhasil diperbarui!'); window.location='pengerjaan.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui status!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengerjaan - SIBEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f1f5f9;
            color: #1e293b;
        }
        .sidebar {
            background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
            z-index: 1045;
            border-right: 1px solid rgba(255, 255, 255, 0.08);
        }
        @media (min-width: 768px) {
            .sidebar {
                height: 100vh;
                position: fixed;
                top: 0; left: 0; bottom: 0;
                width: 25%;
                box-shadow: 4px 0 30px rgba(15, 23, 42, 0.2);
                display: flex;
                flex-direction: column;
                justify-content: space-between;
            }
        }
        @media (min-width: 992px) { .sidebar { width: 16.666667%; } }
        .sidebar-brand-wrapper { padding: 30px 24px 20px 24px; }
        .sidebar-brand {
            font-size: 24px; font-weight: 800; letter-spacing: 1.5px;
            background: linear-gradient(45deg, #38bdf8, #3b82f6);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        }
        .sidebar .nav-link {
            color: #94a3b8; font-size: 14px; font-weight: 500; padding: 14px 24px;
            display: flex; align-items: center; transition: all 0.2s ease; border-left: 4px solid transparent;
        }
        .sidebar .nav-link i { font-size: 16px; width: 28px; color: #64748b; }
        .sidebar .nav-link:hover { color: #38bdf8; background: rgba(255, 255, 255, 0.04); }
        .sidebar .nav-link.active {
            background: rgba(56, 189, 248, 0.1); color: #38bdf8; font-weight: 600; border-left-color: #38bdf8;
        }
        
        .main-wrapper { padding: 20px; margin-left: 0; transition: all 0.3s ease; }
        @media (min-width: 768px) { .main-wrapper { margin-left: 25%; padding: 40px; } }
        @media (min-width: 992px) { .main-wrapper { margin-left: 16.666667%; } }
        
        .table-premium {
            background: white; border-radius: 24px; box-shadow: 0 4px 18px rgba(148, 163, 184, 0.08); padding: 25px;
        }
        .table-premium thead th {
            background-color: #f8fafc; color: #64748b; font-size: 12px; font-weight: 700; text-transform: uppercase; padding: 16px 20px; border-bottom: none;
        }
        .table-premium tbody td { padding: 18px 20px; border-bottom: 1px solid #f1f5f9; color: #475569; font-size: 14px; }
    </style>
</head>
<body>

<div class="bg-dark text-white d-md-none p-3 sticky-top d-flex justify-content-between align-items-center shadow-sm">
    <div class="d-flex align-items-center gap-2">
        <div class="fw-bold fs-5" style="background: linear-gradient(45deg, #38bdf8, #3b82f6); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">SIBEO</div>
    </div>
    <button class="btn btn-outline-light btn-sm px-2.5" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu">
        <i class="fa-solid fa-bars"></i> Menu
    </button>
</div>

<div class="container-fluid p-0">
    <div class="offcanvas-md offcanvas-start sidebar" tabindex="-1" id="sidebarMenu">
        <div class="d-flex flex-column justify-content-between h-100 w-100">
            <div>
                <div class="sidebar-brand-wrapper d-flex justify-content-between align-items-center">
                    <div class="sidebar-brand">SIBEO</div>
                    <button type="button" class="btn-close btn-close-white d-md-none" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu"></button>
                </div>
                <div class="nav flex-column">
                    <a href="dashboard.php" class="nav-link"><i class="fa-solid fa-chart-simple me-3"></i>Dashboard Kerja</a>
                    <a href="pengerjaan.php" class="nav-link active"><i class="fa-solid fa-screwdriver-wrench me-3"></i>Pengerjaan</a>
                    <a href="peminjaman_alat.php" class="nav-link"><i class="fa-solid fa-boxes-stacked me-3"></i>Peminjaman Alat</a>
                </div>
            </div>
            <div class="mb-4 pt-2 border-top border-secondary">
                <div class="nav flex-column">
                    <a href="../auth/logout.php" class="nav-link text-danger" onclick="return confirm('Keluar dari sistem')"><i class="fa-solid fa-sign-out-alt me-3 text-danger"></i>Keluar</a>
                </div>
            </div>
        </div>
    </div>

    <div class="main-wrapper">
        <div class="mb-4 d-flex justify-content-between align-items-center">
            <div>
                <h3 class="fw-bold m-0 text-dark">Daftar Tugas Pengerjaan</h3>
                <p class="text-muted small m-0 mt-1">Kelola status dan berikan catatan perbaikan pada kendaraan pelanggan.</p>
            </div>
        </div>

        <div class="table-premium">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>KODE</th>
                            <th>KENDARAAN & PLAT</th>
                            <th>LAYANAN & KELUHAN</th>
                            <th>WAKTU MULAI / SELESAI</th>
                            <th>STATUS</th>
                            <th class="text-center">AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    // Query data pengerjaan murni berdasarkan atribut tabel baru Anda
                    $query_pengerjaan = mysqli_query($koneksi, "SELECT p.*, b.kode_booking, b.keluhan, k.merk, k.nomor_polisi, l.nama_paket 
                                                                FROM tbl_pengerjaan p
                                                                JOIN tbl_booking b ON p.id_booking = b.id_booking
                                                                JOIN tbl_kendaraan k ON b.id_kendaraan = k.id_kendaraan
                                                                JOIN tbl_paket_layanan l ON b.id_paket = l.id_paket
                                                                WHERE p.id_mekanik = '$id_mekanik'
                                                                ORDER BY p.id_pengerjaan DESC");

                    if (!$query_pengerjaan || mysqli_num_rows($query_pengerjaan) == 0) {
                        echo "<tr><td colspan='6' class='text-center text-muted py-4 small'>Belum ada daftar pengerjaan yang ditugaskan.</td></tr>";
                    } else {
                        while ($r = mysqli_fetch_assoc($query_pengerjaan)) {
                            $status = $r['status_pengerjaan'];
                            $badge = "bg-warning text-warning";
                            if ($status == "Selesai") $badge = "bg-success text-success";
                            elseif ($status == "Sedang Dikerjakan" || $status == "Proses") $badge = "bg-primary text-primary";
                            ?>
                            <tr>
                                <td class="fw-bold text-primary"><?= $r['kode_booking']; ?></td>
                                <td class="fw-semibold">
                                    <?= htmlspecialchars($r['merk']); ?>
                                    <br><code class="text-secondary small fw-bold"><?= htmlspecialchars($r['nomor_polisi']); ?></code>
                                </td>
                                <td>
                                    <span class="fw-medium"><?= htmlspecialchars($r['nama_paket']); ?></span>
                                    <br><small class="text-muted d-block" style="max-width: 250px; font-size: 11px;">Ket: <?= !empty($r['keluhan']) ? htmlspecialchars($r['keluhan']) : '-'; ?></small>
                                </td>
                                <td style="font-size: 13px;">
                                    <div><i class="fa-solid fa-play text-muted me-1 small"></i> <?= (!empty($r['waktu_mulai']) && $r['waktu_mulai'] != '0000-00-00 00:00:00') ? $r['waktu_mulai'] : '-'; ?></div>
                                    <div class="mt-1"><i class="fa-solid fa-flag-checkered text-muted me-1 small"></i> <?= (!empty($r['waktu_selesai']) && $r['waktu_selesai'] != '0000-00-00 00:00:00') ? $r['waktu_selesai'] : '-'; ?></div>
                                </td>
                                <td>
                                    <span class="badge bg-opacity-10 <?= $badge; ?> px-2.5 py-1.5 rounded" style="font-size: 12px; font-weight: 600;"><?= $status; ?></span>
                                    <?php if(!empty($r['catatan_mekanik'])): ?>
                                        <br><small class="text-secondary" style="font-size: 11px;"><i>Note: <?= htmlspecialchars($r['catatan_mekanik']); ?></i></small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-primary px-3 rounded-pill" data-bs-toggle="modal" data-bs-target="#modalUpdate<?= $r['id_pengerjaan']; ?>">
                                        <i class="fa-solid fa-pen-to-square me-1"></i> Update
                                    </button>
                                </td>
                            </tr>

                            <div class="modal fade" id="modalUpdate<?= $r['id_pengerjaan']; ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content" style="border-radius: 16px;">
                                        <form method="POST" action="">
                                            <div class="modal-header">
                                                <h5 class="modal-title fw-bold">Update Pengerjaan - <?= $r['kode_booking']; ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <input type="hidden" name="id_pengerjaan" value="<?= $r['id_pengerjaan']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold small text-muted">STATUS PENGERJAAN</label>
                                                    <select class="form-select" name="status_pengerjaan" required>
                                                        <option value="Pending" <?= ($status == 'Pending') ? 'selected' : ''; ?>>Pending (Belum Dikerjakan)</option>
                                                        <option value="Sedang Dikerjakan" <?= ($status == 'Sedang Dikerjakan' || $status == 'Proses') ? 'selected' : ''; ?>>Sedang Dikerjakan</option>
                                                        <option value="Selesai" <?= ($status == 'Selesai') ? 'selected' : ''; ?>>Selesai</option>
                                                    </select>
                                                </div>

                                                <div class="mb-2">
                                                    <label class="form-label fw-semibold small text-muted">CATATAN MEKANIK</label>
                                                    <textarea class="form-select" name="catatan_mekanik" rows="3" placeholder="Contoh: Oli sudah diganti, rem depan dibersihkan..."><?= htmlspecialchars($r['catatan_mekanik']); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" name="update_pengerjaan" class="btn btn-sm btn-primary px-3">Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>