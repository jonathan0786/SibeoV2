<?php
session_start();
include "../config/koneksi.php";

// 1. KEAMANAN AKSES
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'mekanik') {
    header("Location: ../auth/login.php");
    exit();
}

$id_mekanik = $_SESSION['id'];

// 2. QUERY DETAIL MEKANIK
$query_mekanik = mysqli_query($koneksi, "SELECT id_mekanik, nama, kepegawaian, spesialisasi, shift FROM tbl_mekanik WHERE id_mekanik = '$id_mekanik'");
$data_mekanik = mysqli_fetch_assoc($query_mekanik);

// 3. HITUNG STATISTIK BERDASARKAN TBL_PENGERJAAN
// Hitung tugas aktif (Membaca dari status di tbl_pengerjaan)
$query_proses = mysqli_query($koneksi, "SELECT id_pengerjaan FROM tbl_pengerjaan WHERE id_mekanik = '$id_mekanik' AND status IN ('Pending', 'Proses', 'Sedang Dikerjakan')");
$tugas_proses = $query_proses ? mysqli_num_rows($query_proses) : 0;

// Hitung tugas selesai
$query_selesai = mysqli_query($koneksi, "SELECT id_pengerjaan FROM tbl_pengerjaan WHERE id_mekanik = '$id_mekanik' AND status = 'Selesai'");
$tugas_selesai = $query_selesai ? mysqli_num_rows($query_selesai) : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Mekanik - SIBEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f1f5f9;
            color: #1e293b;
        }
        /* SideBar (Sama Persis dengan Admin) */
        .sidebar {
            background: #111625;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            z-index: 999;
            box-shadow: 4px 0 24px rgba(0, 0, 0, 0.15);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .sidebar-brand-wrapper {
            padding: 20px 24px 10px 24px;
        }
        .sidebar-brand {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: 1.5px;
            color: #38bdf8;
        }
        .sidebar-subtitle {
            font-size: 9px; 
            font-weight: 700;
            letter-spacing: 1px; 
            color: #475569;
            margin-top: 2px;
            text-transform: uppercase;
        }
        .nav-section-title {
            font-size: 10px;
            font-weight: 800;
            color: #334155;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            padding: 15px 24px 6px 24px;
        }
        .sidebar .nav-link {
            color: #94a3b8;
            font-size: 14px;
            font-weight: 600;
            padding: 9px 24px; 
            display: flex;
            align-items: center;
            transition: all 0.2s ease;
            border-left: 4px solid transparent;
            text-decoration: none;
        }
        .sidebar .nav-link i {
            font-size: 16px;
            width: 28px;
            color: #64748b;
            transition: all 0.2s ease;
        }
        .sidebar .nav-link:hover {
            color: #38bdf8;
            background: rgba(56, 189, 248, 0.04);
        }
        .sidebar .nav-link:hover i {
            color: #38bdf8;
        }
        .sidebar .nav-link.active {
            background: rgba(59, 130, 246, 0.12);
            color: #3b82f6;
            font-weight: 700;
            border-left-color: #3b82f6;
        }
        .sidebar .nav-link.active i {
            color: #3b82f6;
        }
        .logout-link {
            color: #ef4444 !important;
            font-weight: 700 !important;
        }
        .logout-link i {
            color: #ef4444 !important;
        }
        .logout-link:hover {
            background: rgba(239, 68, 68, 0.08) !important;
        }
        
        /* Main Section */
        .main-wrapper {
            margin-left: 16.666667%; 
            padding: 40px;
        }
        .welcome-banner {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            border-radius: 24px;
            padding: 35px;
            color: white;
            box-shadow: 0 10px 30px rgba(15, 23, 42, 0.08);
        }
        .welcome-banner p {
            color: rgba(255, 255, 255, 0.7) !important;
        }

        /* Card Info */
        .stat-card-premium {
            background: white;
            border: none;
            border-radius: 24px;
            padding: 28px;
            box-shadow: 0 4px 18px rgba(148, 163, 184, 0.08);
            height: 100%;
        }
        .icon-shape {
            width: 50px;
            height: 50px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }
        
        /* Tabel */
        .table-premium {
            background: white;
            border-radius: 24px;
            box-shadow: 0 4px 18px rgba(148, 163, 184, 0.08);
            padding: 25px;
        }
        .table-premium thead th {
            background-color: #f8fafc;
            color: #64748b;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 16px 20px;
            border-bottom: none;
        }
        .table-premium tbody td {
            padding: 18px 20px;
            border-bottom: 1px solid #f1f5f9;
            color: #475569;
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="container-fluid p-0">
    <div class="row g-0">
        
        <div class="col-md-3 col-lg-2 sidebar">
            <div>
                <div class="sidebar-brand-wrapper text-start ps-4">
                    <div class="sidebar-brand">SIBEO</div>
                    <div class="sidebar-subtitle">Mechanic SYSTEM</div>
                </div>
                
                <div class="nav-section-title">MENU WORKSPACE</div>
                <div class="nav flex-column">
                    <a href="dashboard.php" class="nav-link active"><i class="fa-solid fa-chart-simple me-3"></i>Dashboard Kerja</a>
                    <a href="pengerjaan.php" class="nav-link"><i class="fa-solid fa-screwdriver-wrench me-3"></i>Pengerjaan</a>
                    <a href="peminjaman_alat.php" class="nav-link"><i class="fa-solid fa-boxes-stacked me-3"></i>Peminjaman Alat</a>
                </div>
            </div>
            
            <div class="mb-3 pt-2">
                <div class="nav flex-column">
                    <a href="../auth/logout.php" class="nav-link logout-link" onclick="return confirm('Keluar dari sistem?')">
                        <i class="fa-solid fa-sign-out-alt me-3"></i>Keluar
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-9 col-lg-10 main-wrapper">
            
            <div class="welcome-banner mb-4">
                <span class="badge mb-3 px-3 py-2" style="font-size: 11px; font-weight: 800; letter-spacing: 1px; background: rgba(255, 255, 255, 0.15); color: #ffffff !important; border: 1px solid rgba(255, 255, 255, 0.25);">MECHANIC AREA</span>
                <h1 class="fw-bold m-0 mb-2" style="font-size: 28px; letter-spacing: -0.5px;">Selamat Datang, <?= htmlspecialchars($data_mekanik['nama'] ?? 'Mekanik'); ?>!</h1>
                <p class="small m-0">Spesialisasi: <strong class="text-white"><?= htmlspecialchars($data_mekanik['spesialisasi'] ?? '-'); ?></strong> | Shift: <strong class="text-white text-capitalize"><?= htmlspecialchars($data_mekanik['shift'] ?? '-'); ?></strong></p>
            </div>

            <h6 class="fw-bold text-uppercase mb-3" style="font-size: 11px; letter-spacing: 1px; color: #64748b;"><i class="fa-solid fa-bolt me-2 text-warning"></i>Statistik Performa Hari Ini</h6>
            <div class="row g-4 mb-5">
                
                <div class="col-md-6">
                    <div class="stat-card-premium">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                                <span class="text-muted text-uppercase fw-bold" style="font-size: 11px; letter-spacing: 0.5px; color: #94a3b8 !important;">TUGAS AKTIF HARI INI</span>
                                <h2 class="fw-extrabold mb-0 mt-2" style="color: #0f172a; font-size: 32px; font-weight: 800;"><?= $tugas_proses; ?> <span style="font-size: 14px; font-weight: 500; color: #64748b;">Antrean</span></h2>
                            </div>
                            <div class="icon-shape bg-warning bg-opacity-10 text-warning">
                                <i class="fa-solid fa-spinner fa-spin"></i>
                            </div>
                        </div>
                        <div class="mt-3 pt-3 border-top border-light">
                            <a href="pengerjaan.php" class="text-decoration-none small fw-bold text-warning" style="color: #d97706 !important;">Mulai Pengerjaan &rarr;</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="stat-card-premium">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                                <span class="text-muted text-uppercase fw-bold" style="font-size: 11px; letter-spacing: 0.5px; color: #94a3b8 !important;">TOTAL TUGAS SELESAI</span>
                                <h2 class="fw-extrabold mb-0 mt-2" style="color: #10b981; font-size: 32px; font-weight: 800;"><?= $tugas_selesai; ?> <span style="font-size: 14px; font-weight: 500; color: #64748b;">Selesai</span></h2>
                            </div>
                            <div class="icon-shape bg-success bg-opacity-10 text-success">
                                <i class="fa-solid fa-circle-check"></i>
                            </div>
                        </div>
                        <div class="mt-3 pt-3 border-top border-light">
                            <a href="pengerjaan.php" class="text-decoration-none small fw-bold text-success">Lihat Riwayat Tugas &rarr;</a>
                        </div>
                    </div>
                </div>

            </div>

            <div class="table-premium">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h5 class="fw-bold m-0" style="color: #0f172a;">Antrean Tugas Terkini</h5>
                        <p class="text-muted small m-0 mt-1">Daftar kendaraan pelanggan yang sedang atau akan Anda kerjakan.</p>
                    </div>
                    <a href="pengerjaan.php" class="btn btn-sm btn-outline-secondary rounded-3 px-3 py-1.5 fw-semibold" style="font-size: 12px;">Lihat Semua</a>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>KODE ANTREAN</th>
                                <th>KENDARAAN & PLAT</th>
                                <th>LAYANAN & DETAIL KELUHAN</th>
                                <th>WAKTU MULAI</th>
                                <th class="text-center">STATUS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $tampil_tugas = mysqli_query($koneksi, "SELECT p.status, p.waktu_mulai, b.kode_booking, b.keluhan, k.merk, k.nomor_polisi, l.nama_paket 
                                                                    FROM tbl_pengerjaan p
                                                                    JOIN tbl_booking b ON p.id_booking = b.id_booking
                                                                    JOIN tbl_kendaraan k ON b.id_kendaraan = k.id_kendaraan 
                                                                    JOIN tbl_paket_layanan l ON b.id_paket = l.id_paket
                                                                    WHERE p.id_mekanik = '$id_mekanik' 
                                                                    ORDER BY p.id_pengerjaan DESC LIMIT 3");
                                                                    
                            if (!$tampil_tugas || mysqli_num_rows($tampil_tugas) == 0) {
                                echo "<tr><td colspan='5' class='text-center text-muted small py-4'>Belum ada riwayat pengerjaan tugas.</td></tr>";
                            } else {
                                while ($r = mysqli_fetch_assoc($tampil_tugas)) {
                                    $status = $r['status']; 
                                    $badge_class = "bg-warning text-warning";
                                    
                                    if ($status == "Selesai") {
                                        $badge_class = "bg-success text-success";
                                    } elseif ($status == "Sedang Dikerjakan" || $status == "Proses") {
                                        $badge_class = "bg-primary text-primary";
                                    }
                                    ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= $r['kode_booking']; ?></td>
                                        <td class="fw-semibold" style="color: #0f172a;">
                                            <?= htmlspecialchars($r['merk']); ?> 
                                            (<code class="text-secondary"><?= htmlspecialchars($r['nomor_polisi']); ?></code>)
                                        </td>
                                        <td>
                                            <span class="fw-medium"><?= htmlspecialchars($r['nama_paket']); ?></span>
                                            <br><small class="text-muted" style="font-size: 11px;">Ket: <?= (!empty($r['keluhan'])) ? htmlspecialchars($r['keluhan']) : '-'; ?></small>
                                        </td>
                                        <td><?= (!empty($r['waktu_mulai'])) ? $r['waktu_mulai'] : '-'; ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-opacity-10 <?= $badge_class; ?> px-2 py-1 rounded small" style="font-size: 12px; font-weight: 600;"><?= $status; ?></span>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div> </div> </div> <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>